const express = require('express');
const session = require('express-session');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const axios = require('axios');
const crypto = require('crypto');
const app = express();

// SEO Meta Verisi Fonksiyonu
function generateSEOMeta(title, description, url, image) {
    return {
        title: title || 'Evizle - Emlak Video Portali',
        description: description || 'Balikesir ve Canakkale\'da en iyi emlak ilanlarini video ile izleyin. Evizle ile hayalinizdeki evi bulun.',
        url: url || 'https://evizle.com',
        image: image || 'https://evizle.com/og-image.jpg',
        keywords: 'emlak, video, balikesir, canakkale, villa, daire, arsa'
    };
}

// Veritabanı bağlantısı
const db = new sqlite3.Database('./emlak.db', (err) => {
    if (err) console.error('Veritabanı bağlantı hatası:', err);
    else {
        console.log('Veritabanı bağlantısı başarılı.');
        initDB();
    }
});

function initDB() {
    db.serialize(() => {
        // Kullanıcılar Tablosu
        db.run(`CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE,
            password TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )`);

        // İlanlar Tablosu
        db.run(`CREATE TABLE IF NOT EXISTS listings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            video_id TEXT UNIQUE,
            title TEXT,
            description TEXT,
            shared_by TEXT,
            price TEXT,
            city TEXT,
            district TEXT,
            neighborhood TEXT,
            type TEXT,
            tags TEXT,
            views INTEGER DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )`);

        // Kullanıcı Aktivite Takibi
        db.run(`CREATE TABLE IF NOT EXISTS user_activity (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            listing_id INTEGER,
            action TEXT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(user_id) REFERENCES users(id),
            FOREIGN KEY(listing_id) REFERENCES listings(id)
        )`);

        // Varsayılan Admin
        db.get("SELECT * FROM users WHERE username = 'admin'", (err, row) => {
            if (!row) {
                db.run("INSERT INTO users (username, password) VALUES ('admin', 'admin123')");
                console.log('Varsayılan admin oluşturuldu: admin / admin123');
            }
        });
    });
}

app.set('view engine', 'ejs');
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.use(session({
    secret: 'emlakvideo-cok-gizli-anahtar',
    resave: false,
    saveUninitialized: true
}));

function timeAgo(date) {
    const now = new Date();
    const past = new Date(date + " UTC");
    const seconds = Math.floor((now - past) / 1000);
    
    if (seconds < 60) return "Az önce";
    let interval = seconds / 31536000;
    if (interval > 1) return Math.floor(interval) + " yıl önce";
    interval = seconds / 2592000;
    if (interval > 1) return Math.floor(interval) + " ay önce";
    interval = seconds / 86400;
    if (interval > 1) return Math.floor(interval) + " gün önce";
    interval = seconds / 3600;
    if (interval > 1) return Math.floor(interval) + " saat önce";
    interval = seconds / 60;
    if (interval > 1) return Math.floor(interval) + " dakika önce";
    return "Az önce";
}

function generateVideoID() {
    return crypto.randomBytes(6).toString('hex').toUpperCase();
}

function extractVideoID(url) {
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
    const match = url.match(regExp);
    return (match && match[2].length === 11) ? match[2] : url;
}

async function getYouTubeData(videoId) {
    try {
        const response = await axios.get(`https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=${videoId}&format=json`);
        return {
            title: response.data.title || '',
            author: response.data.author_name || ''
        };
    } catch (error) {
        return { title: '', author: '' };
    }
}

function trackUserActivity(userId, listingId, action) {
    if (userId) {
        db.run("INSERT INTO user_activity (user_id, listing_id, action) VALUES (?, ?, ?)", 
            [userId, listingId, action]);
    }
}

function getStats(callback) {
    db.get("SELECT COUNT(*) as total_listings, SUM(views) as total_views FROM listings", (err, row) => {
        const stats = {
            total_listings: row?.total_listings || 0,
            total_views: row?.total_views || 0
        };
        
        db.all("SELECT city, COUNT(*) as count, SUM(views) as views FROM listings GROUP BY city ORDER BY views DESC LIMIT 5", (err, cities) => {
            stats.top_cities = cities || [];
            
            db.all("SELECT type, COUNT(*) as count FROM listings GROUP BY type", (err, types) => {
                stats.types = types || [];
                callback(stats);
            });
        });
    });
}

app.get('/', (req, res) => {
    const { city, district, neighborhood, type, minPrice, maxPrice, sort } = req.query;
    let query = "SELECT * FROM listings WHERE 1=1";
    let params = [];

    if (city) { query += " AND city = ?"; params.push(city); }
    if (district) { query += " AND district = ?"; params.push(district); }
    if (neighborhood) { query += " AND neighborhood = ?"; params.push(neighborhood); }
    if (type) { query += " AND type = ?"; params.push(type); }

    if (minPrice) {
        query += " AND CAST(REPLACE(REPLACE(price, '.', ''), ',', '') AS INTEGER) >= ?";
        params.push(minPrice);
    }
    if (maxPrice) {
        query += " AND CAST(REPLACE(REPLACE(price, '.', ''), ',', '') AS INTEGER) <= ?";
        params.push(maxPrice);
    }

    if (sort === 'price-asc') query += " ORDER BY CAST(REPLACE(REPLACE(price, '.', ''), ',', '') AS INTEGER) ASC";
    else if (sort === 'price-desc') query += " ORDER BY CAST(REPLACE(REPLACE(price, '.', ''), ',', '') AS INTEGER) DESC";
    else if (sort === 'views') query += " ORDER BY views DESC";
    else query += " ORDER BY id DESC";

    db.all(query, params, (err, rows) => {
        if (err) return res.status(500).send("Veritabanı hatası: " + err.message);
        const formattedRows = (rows || []).map(row => ({ ...row, time_ago: timeAgo(row.created_at) }));
        const favorites = req.session.favorites || [];
        
        if (req.session.user && req.session.user.username === 'admin') {
            getStats((statsData) => {
                res.render('index', { 
                    listings: formattedRows, 
                    user: req.session.user || null,
                    page: 'home',
                    filters: { city, district, neighborhood, type, minPrice, maxPrice, sort },
                    favorites: favorites,
                    stats: statsData
                });
            });
        } else {
            res.render('index', { 
                listings: formattedRows, 
                user: req.session.user || null,
                page: 'home',
                filters: { city, district, neighborhood, type, minPrice, maxPrice, sort },
                favorites: favorites,
                stats: null
            });
        }
    });
});

app.get('/explore', (req, res) => {
    db.all("SELECT * FROM listings ORDER BY RANDOM() LIMIT 12", [], (err, rows) => {
        const formattedRows = (rows || []).map(row => ({ ...row, time_ago: timeAgo(row.created_at) }));
        const favorites = req.session.favorites || [];
        res.render('index', { listings: formattedRows, user: req.session.user || null, page: 'explore', filters: {}, favorites: favorites, stats: null });
    });
});

app.get('/history', (req, res) => {
    const historyIds = req.session.history || [];
    if (historyIds.length === 0) return res.render('index', { listings: [], user: req.session.user || null, page: 'history', filters: {}, favorites: [], stats: null });
    const placeholders = historyIds.map(() => '?').join(',');
    db.all(`SELECT * FROM listings WHERE id IN (${placeholders})`, historyIds, (err, rows) => {
        const sortedRows = historyIds.map(id => (rows || []).find(r => r.id == id)).filter(Boolean).reverse();
        const formattedRows = sortedRows.map(row => ({ ...row, time_ago: timeAgo(row.created_at) }));
        res.render('index', { listings: formattedRows, user: req.session.user || null, page: 'history', filters: {}, favorites: req.session.favorites || [], stats: null });
    });
});

app.get('/favorites', (req, res) => {
    const favorites = req.session.favorites || [];
    if (favorites.length === 0) return res.render('index', { listings: [], user: req.session.user || null, page: 'favorites', filters: {}, favorites: [], stats: null });
    const placeholders = favorites.map(() => '?').join(',');
    db.all(`SELECT * FROM listings WHERE id IN (${placeholders})`, favorites, (err, rows) => {
        const formattedRows = (rows || []).map(row => ({ ...row, time_ago: timeAgo(row.created_at) }));
        res.render('index', { listings: formattedRows, user: req.session.user || null, page: 'favorites', filters: {}, favorites: favorites, stats: null });
    });
});

app.post('/toggle-favorite/:id', (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) return res.status(400).json({ success: false });
    if (!req.session.favorites) req.session.favorites = [];
    const index = req.session.favorites.indexOf(id);
    if (index > -1) req.session.favorites.splice(index, 1);
    else {
        req.session.favorites.push(id);
        trackUserActivity(req.session.user?.id, id, 'favorite');
    }
    res.json({ success: true, isFavorite: index === -1 });
});

app.get('/login', (req, res) => res.render('login'));
app.post('/login', (req, res) => {
    const { username, password } = req.body;
    if (!username || !password || typeof username !== 'string' || typeof password !== 'string') {
        return res.send("Lütfen tüm alanları doldurun. <a href='/login'>Tekrar dene</a>");
    }
    db.get("SELECT * FROM users WHERE username = ? AND password = ?", [username, password], (err, user) => {
        if (user) { req.session.user = user; res.redirect('/'); }
        else res.send("Hatalı kullanıcı adı veya şifre! <a href='/login'>Tekrar dene</a>");
    });
});

app.get('/register', (req, res) => res.render('register'));
app.post('/register', (req, res) => {
    const { username, password } = req.body;
    if (!username || !password || typeof username !== 'string' || typeof password !== 'string') {
        return res.send("Lütfen tüm alanları doldurun.");
    }
    if (username.length < 3 || password.length < 6) return res.send("Kullanıcı adı en az 3, şifre en az 6 karakter olmalıdır.");
    db.run("INSERT INTO users (username, password) VALUES (?, ?)", [username, password], (err) => {
        if (err) return res.send("Bu kullanıcı adı zaten alınmış veya bir hata oluştu. <a href='/register'>Tekrar dene</a>");
        res.redirect('/login');
    });
});

app.get('/logout', (req, res) => { req.session.destroy(); res.redirect('/'); });

app.post('/upload', async (req, res) => {
    if (req.session.user && req.session.user.username === 'admin') {
        const { yt_link, title, price, description, city, district, neighborhood, type, shared_by, tags, auto_fetch } = req.body;
        
        // Validasyon
        if (!title || !price || !description || !city || !district || !neighborhood || !type) {
            return res.send("Tüm alanları doldurun!");
        }
        if (typeof title !== 'string' || typeof price !== 'string' || typeof description !== 'string') {
            return res.send("Geçersiz veri tipi!");
        }
        if (title.length > 200 || description.length > 5000) {
            return res.send("Başlık veya açıklama çok uzun!");
        }
        const youtubeId = extractVideoID(yt_link);
        const videoId = generateVideoID();
        
        if (youtubeId) {
            let finalTitle = title;
            let finalDescription = description;
            let finalSharedBy = shared_by || 'Anonim';
            
            if (auto_fetch === 'on') {
                const ytData = await getYouTubeData(youtubeId);
                if (ytData.title) finalTitle = ytData.title;
                if (ytData.author) finalSharedBy = ytData.author;
            }
            
            db.run("INSERT INTO listings (video_id, title, description, shared_by, price, city, district, neighborhood, type, tags) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            [youtubeId, finalTitle, finalDescription, finalSharedBy, price, city, district, neighborhood, type, tags || ''], (err) => {
                if (err) res.send("İlan eklenirken hata oluştu: " + err.message);
                else res.redirect('/');
            });
        } else res.send("Geçersiz YouTube linki!");
    } else res.status(403).send("Yetkisiz erişim!");
});

app.get('/watch', (req, res) => {
    const { v } = req.query;
    if (!v || typeof v !== 'string' || v.length > 100) return res.status(404).send("İlan bulunamadı.");
    
    db.get("SELECT * FROM listings WHERE video_id = ?", [v], (err, row) => {
        if (err) return res.status(500).send("Veritabanı hatası: " + err.message);
        if (!row) return res.status(404).send("İlan bulunamadı.");
        
        if (!req.session.history) req.session.history = [];
        req.session.history = req.session.history.filter(hId => hId !== row.id);
        req.session.history.push(row.id);
        if (req.session.history.length > 20) req.session.history.shift();
        
        db.run("UPDATE listings SET views = views + 1 WHERE id = ?", [row.id]);
        trackUserActivity(req.session.user?.id, row.id, 'view');
        
        row.time_ago = timeAgo(row.created_at);
        
        // Önerilen ilanları getir
        db.all("SELECT * FROM listings WHERE id != ? ORDER BY RANDOM() LIMIT 6", [row.id], (err, recommended) => {
            const formattedRecommended = (recommended || []).map(r => ({ ...r, time_ago: timeAgo(r.created_at) }));
            res.render('video', { 
                listing: row, 
                user: req.session.user || null, 
                isFavorite: (req.session.favorites || []).includes(row.id),
                videoId: v,
                recommended: formattedRecommended
            });
        });
    });
});

app.get('/admin', (req, res) => {
    if (!req.session.user || req.session.user.username !== 'admin') {
        return res.status(403).send("Yetkisiz erişim!");
    }
    
    getStats((stats) => {
        db.all("SELECT id, username, created_at FROM users LIMIT 100", [], (err, users) => {
            db.all("SELECT u.id, u.username, COUNT(DISTINCT ua.listing_id) as viewed_listings, COUNT(DISTINCT CASE WHEN ua.action='favorite' THEN ua.listing_id END) as favorite_count FROM users u LEFT JOIN user_activity ua ON u.id = ua.user_id GROUP BY u.id", [], (err, userStats) => {
                res.render('admin', { 
                    user: req.session.user, 
                    stats: stats,
                    users: users || [],
                    userStats: userStats || []
                });
            });
        });
    });
});

app.get('/admin/listings', (req, res) => {
    if (!req.session.user || req.session.user.username !== 'admin') {
        return res.status(403).send("Yetkisiz erişim!");
    }
    
    db.all("SELECT * FROM listings ORDER BY created_at DESC", [], (err, listings) => {
        listings = (listings || []).map(l => ({ ...l, time_ago: timeAgo(l.created_at) }));
        res.render('admin-listings', { user: req.session.user, listings: listings });
    });
});

app.post('/admin/edit-listing/:id', (req, res) => {
    if (!req.session.user || req.session.user.username !== 'admin') {
        return res.status(403).json({ success: false });
    }
    
    const id = parseInt(req.params.id);
    if (isNaN(id)) return res.status(400).json({ success: false });
    
    const { title, description, tags } = req.body;
    if (!title || !description) return res.status(400).json({ success: false });
    
    db.run("UPDATE listings SET title = ?, description = ?, tags = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?", 
        [title, description, tags || '', id], (err) => {
        res.json({ success: !err });
    });
});

app.get('/admin/delete/:id', (req, res) => {
    if (!req.session.user || req.session.user.username !== 'admin') {
        return res.status(403).send("Yetkisiz!");
    }
    const id = parseInt(req.params.id);
    if (isNaN(id)) return res.status(400).send("Geçersiz ID");
    db.run("DELETE FROM listings WHERE id = ?", [id], () => res.redirect('/admin/listings'));
});

app.listen(3000, () => console.log('EmlakVideo http://localhost:3000 adresinde yayında!'));
